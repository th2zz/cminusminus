int *bla3, bla4;
long int bla5[];
volatile int short *bla7;
int a;

int *funktion(int b);

int c;


void fkt(int *funktion()){
    int *a[0];

}
int volatile long main2(int *d, int b){
    int funca;
    {
        int short blocka1;
        int short blocka2;
	typedef int innerdef;
        {
            int long blockb1;
            int long blockb2;
        }
    }
}
int innerdef;

typedef struct point {
  int j;
  int k;
} p;
p pi;

void help(int short b){} 
int bla2 = 6;
int bla6 = 5;

int vec[][12][5];
long int ass,aai,bb;


typedef volatile int *bla32,bla64=z;
// z testvar3; is rejected!
bla64 testvar2;
bla32 testvar;
bla32 beispiel23();

int nixtest=1,blanix2 = {1,};
enum lustig {red,green,blue} lustig2;
enum lustig lustig1;

typedef int dreck;
const dreck fuzzy=5; 
dreck fuzzy2 = (int)fuzzy;


int orange(){
 
}


int dain(int b[]) {
  struct frucht{
    int farbe;
    int * form[];
  } banane, orange;
}


bla32 versuch5(a,b) int a[]; int b(int x,int y); { 
    int  (*versuch7) (int, int);
    2[a]=0;
    lustig1=green;
    lustig2=red;
    lustig2=1;
    versuch7 = (int (*)(int c,int d)) &a;
    versuch7(5,4);
    bla6=bla6-bla4;
    for (;;) break;
    return a; 
}

versuch6(t) int t(int x,int y); { return 0; }

int i,versuch(), versuch2(int (), int ), blanix(int [],int [3][3]);
int ****pointer, **acc;

int versuch2(int versuch3(), int c){

    int temp1;
    int temp2;
    int temp3 [1||2];
    {
        int i= 7;
        i=5;

        if (1) versuch5();

        for (i=0;i<5;i++) {
            i=c;
        }

    }
    return i;
}


int versuch(){
    return 0;
}

int main(int first, char **argv){
    int bla = 0;
    int nix = 0;
    bla = bla +1, nix = bla;
    printf("Hallo %i \n",nix);
}


